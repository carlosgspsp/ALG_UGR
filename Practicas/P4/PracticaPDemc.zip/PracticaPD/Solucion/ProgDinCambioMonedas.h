#ifndef PROGDINCAMBIOMONEDAS_H_INCLUDED
#define PROGDINCAMBIOMONEDAS_H_INCLUDED

#include "Problema.h"
#include "Solucion.h"

Solucion AlgoritmoProgDinCambioMonedas(const Problema & p);


#endif // PROGDINCAMBIOMONEDAS_H_INCLUDED
